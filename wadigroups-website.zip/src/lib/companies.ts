import type { Company } from "@/components/site/CompanyCard";
import medical from "@/assets/medical.jpg";
import trading from "@/assets/trading.jpg";
import importExport from "@/assets/import-export.jpg";
import contracting from "@/assets/contracting.jpg";

export const companies: Company[] = [
  {
    slug: "medical",
    name: "Wadi Alhaya Medical Equipment LLC",
    industry: "Healthcare & Medical Equipment",
    description: "Advanced medical equipment, diagnostic technology, and healthcare solutions serving hospitals and clinics across the UAE.",
    image: medical,
  },
  {
    slug: "trading",
    name: "Wadi Middle East Trading LLC",
    industry: "Trading & Commercial Solutions",
    description: "Strategic trading operations and commercial partnerships connecting global suppliers with the Middle East market.",
    image: trading,
  },
  {
    slug: "import-export",
    name: "Wadi Middle East Import Export LLC",
    industry: "Import & Export",
    description: "International logistics, freight operations and worldwide trade routes built on reliability and scale.",
    image: importExport,
  },
  {
    slug: "contracting",
    name: "Wadi Al Naam Contracting LLC",
    industry: "Construction & Contracting",
    description: "Construction, engineering and infrastructure development delivering landmark projects across the Emirates.",
    image: contracting,
  },
];

export const companyContent: Record<string, {
  tagline: string;
  overview: string;
  vision: string;
  mission: string;
  services: { title: string; description: string }[];
}> = {
  medical: {
    tagline: "Advancing Healthcare Through Innovation",
    overview: "Wadi Alhaya Medical Equipment LLC delivers cutting-edge medical technology and healthcare solutions to hospitals, clinics and diagnostic centers across the United Arab Emirates and the wider region.",
    vision: "To be the most trusted medical equipment partner in the Middle East, elevating patient care through innovation and uncompromising quality.",
    mission: "We empower healthcare providers with reliable, world-class equipment and services that improve outcomes, efficiency and accessibility.",
    services: [
      { title: "Diagnostic Equipment", description: "Imaging systems, laboratory analyzers and advanced diagnostic technology." },
      { title: "Hospital Solutions", description: "Surgical, ICU and patient-care equipment for modern healthcare facilities." },
      { title: "Medical Consumables", description: "High-quality consumables and disposables from certified manufacturers." },
      { title: "Service & Maintenance", description: "Installation, training and lifecycle support from a certified team." },
    ],
  },
  trading: {
    tagline: "Bridging Markets, Building Partnerships",
    overview: "Wadi Middle East Trading LLC operates a diversified trading portfolio, connecting global suppliers with businesses across the GCC through strategic commercial relationships.",
    vision: "To be the Middle East's most agile and trusted commercial trading partner, recognised for integrity and execution.",
    mission: "Deliver intelligent trading solutions that unlock value for clients, partners and the markets we serve.",
    services: [
      { title: "Wholesale Distribution", description: "Bulk distribution across consumer, industrial and commercial categories." },
      { title: "Sourcing & Procurement", description: "End-to-end sourcing from vetted international manufacturers." },
      { title: "Brand Representation", description: "Authorised representation for leading international brands in the UAE." },
      { title: "Market Intelligence", description: "Insight-led commercial strategy tailored to regional opportunities." },
    ],
  },
  "import-export": {
    tagline: "Moving the World, Powering Trade",
    overview: "Wadi Middle East Import Export LLC handles international freight, logistics and global trade flows with the precision and scale required by modern enterprise.",
    vision: "To be the logistics backbone of UAE international commerce, trusted for speed, transparency and resilience.",
    mission: "Engineer seamless global trade through integrated logistics, compliance and strategic partnerships.",
    services: [
      { title: "Sea Freight", description: "Full-container and LCL shipping across major global routes." },
      { title: "Air & Land Freight", description: "Expedited air cargo and regional overland transport." },
      { title: "Customs & Compliance", description: "Documentation, clearance and regulatory compliance services." },
      { title: "Warehousing & Distribution", description: "Bonded warehousing and last-mile distribution across the GCC." },
    ],
  },
  contracting: {
    tagline: "Engineering Tomorrow's Skylines",
    overview: "Wadi Al Naam Contracting LLC delivers construction, engineering and infrastructure projects of every scale — from luxury developments to commercial complexes.",
    vision: "To shape the future of the UAE's built environment with landmark projects defined by quality, safety and craftsmanship.",
    mission: "Build with precision, integrity and innovation — delivering value that lasts generations.",
    services: [
      { title: "Building Construction", description: "Residential, commercial and mixed-use developments delivered turnkey." },
      { title: "Civil & Infrastructure", description: "Roads, utilities and infrastructure for public and private clients." },
      { title: "Fit-Out & Interiors", description: "Premium interior fit-out for offices, retail and hospitality." },
      { title: "Engineering Consultancy", description: "Design, project management and engineering advisory services." },
    ],
  },
};
