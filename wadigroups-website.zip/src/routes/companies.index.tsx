import { createFileRoute } from "@tanstack/react-router";
import { SectionHeading } from "@/components/site/SectionHeading";
import { CompanyCard } from "@/components/site/CompanyCard";
import { companies } from "@/lib/companies";

export const Route = createFileRoute("/companies/")({
  head: () => ({
    meta: [
      { title: "Our Companies — WADI GROUPS" },
      { name: "description", content: "Explore the four companies of WADI GROUPS — across Healthcare, Trading, Import Export and Contracting." },
    ],
  }),
  component: CompaniesIndex,
});

function CompaniesIndex() {
  return (
    <section className="container mx-auto px-6 py-24">
      <SectionHeading eyebrow="Our Group" title={<>Companies of <span className="gradient-gold-text">WADI GROUPS</span></>} subtitle="Four specialised companies operating across the most vital industries of the UAE economy." />
      <div className="grid md:grid-cols-2 gap-6">
        {companies.map((c, i) => <CompanyCard key={c.slug} c={c} index={i} />)}
      </div>
    </section>
  );
}
