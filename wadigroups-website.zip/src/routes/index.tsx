import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import { ArrowRight, Award, Building2, Globe2, Sparkles, ShieldCheck, Users, Trophy, Briefcase } from "lucide-react";
import logo from "@/assets/wadi-logo.png";
import hero from "@/assets/hero-dubai.jpg";
import { companies } from "@/lib/companies";
import { CompanyCard } from "@/components/site/CompanyCard";
import { SectionHeading } from "@/components/site/SectionHeading";
import { GoldParticles } from "@/components/site/GoldParticles";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "WADI GROUPS — Luxury UAE Business Group" },
      { name: "description", content: "Building excellence across Healthcare, Trading, Import Export and Contracting industries in the UAE." },
    ],
  }),
  component: Home,
});

const stats = [
  { value: "15+", label: "Years of Experience" },
  { value: "500+", label: "Successful Projects" },
  { value: "4", label: "Business Sectors" },
  { value: "1000+", label: "Clients Served" },
  { value: "120+", label: "Strategic Partners" },
];

const whyUs = [
  { icon: Award, title: "Industry Expertise", desc: "Decades of cross-sector mastery." },
  { icon: Users, title: "Professional Team", desc: "World-class talent across all divisions." },
  { icon: ShieldCheck, title: "Trusted Reputation", desc: "Built on integrity and delivery." },
  { icon: Sparkles, title: "Innovation", desc: "Modern thinking, future-ready solutions." },
  { icon: Trophy, title: "Quality Assurance", desc: "Uncompromising standards at every step." },
  { icon: Globe2, title: "UAE Market Leadership", desc: "Deep roots, global reach." },
  { icon: Briefcase, title: "Long-Term Partnerships", desc: "Relationships built to last." },
  { icon: Building2, title: "Multi-Industry Scale", desc: "Four core sectors under one vision." },
];

const timeline = [
  { year: "Foundation", title: "Group Established", desc: "WADI GROUPS founded in Dubai with a vision of multi-industry excellence." },
  { year: "Expansion", title: "Healthcare Division", desc: "Launched Wadi Alhaya Medical Equipment to serve UAE's healthcare sector." },
  { year: "Diversification", title: "Trading & Logistics", desc: "Expanded into trading, import-export and international logistics." },
  { year: "Growth", title: "Contracting Division", desc: "Wadi Al Naam Contracting joins the group, entering construction." },
  { year: "Future", title: "Regional Leadership", desc: "Continued expansion across the GCC and emerging international markets." },
];

function Home() {
  return (
    <>
      {/* HERO */}
      <section className="relative min-h-[92vh] overflow-hidden">
        <div className="absolute inset-0">
          <img src={hero} alt="Dubai skyline" className="h-full w-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/70 to-background" />
        </div>
        <GoldParticles count={36} />
        <div className="relative container mx-auto px-6 pt-24 pb-16 md:pt-16 md:pb-24 grid lg:grid-cols-2 gap-10 lg:gap-12 items-center min-h-[92vh]">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
              className="inline-flex items-center gap-3 glass rounded-full px-4 py-1.5 text-[10px] sm:text-xs uppercase tracking-[0.3em] text-gold mb-6"
            >
              <span className="h-1.5 w-1.5 rounded-full bg-gold animate-glow-pulse" /> United Arab Emirates
            </motion.div>
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.1 }}
              className="font-display text-4xl sm:text-5xl md:text-7xl leading-[0.95]"
            >
              <span className="gradient-gold-text">WADI</span>
              <br />
              <span className="text-foreground">GROUPS</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }}
              className="mt-6 max-w-xl text-base sm:text-lg text-muted-foreground"
            >
              Building Excellence Across Healthcare, Trading, Import Export & Contracting Industries in the UAE.
            </motion.p>
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 }} className="mt-8 flex flex-wrap gap-3 sm:gap-4">
              <Link to="/companies" className="btn-gold rounded-full px-5 sm:px-7 py-3 text-sm font-medium inline-flex items-center gap-2">
                Explore Companies <ArrowRight size={16} />
              </Link>
              <Link to="/contact" className="btn-ghost-gold rounded-full px-5 sm:px-7 py-3 text-sm font-medium">
                Contact Us
              </Link>
            </motion.div>
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.8 }} className="mt-10 grid sm:grid-cols-2 gap-3">
              {companies.map((c) => (
                <div key={c.slug} className="glass rounded-lg px-4 py-3 text-sm">
                  <span className="text-gold mr-2">◆</span>{c.name}
                </div>
              ))}
            </motion.div>
          </div>

          {/* Logo showcase */}
          <div className="relative flex items-center justify-center order-first lg:order-last">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1 }}
              className="relative w-[min(85vw,420px)] aspect-square"
            >
              <div className="absolute inset-0 rounded-full animate-glow-pulse" style={{ background: "radial-gradient(circle, oklch(0.82 0.15 85 / 0.35), transparent 70%)" }} />
              <div className="absolute inset-[4%] rounded-full border border-[color:var(--gold)]/40 animate-spin-slow" />
              <div className="absolute inset-[12%] rounded-full border border-[color:var(--gold)]/20 animate-spin-slow" style={{ animationDuration: "40s", animationDirection: "reverse" }} />
              <div className="absolute inset-[20%] rounded-full grid place-items-center animate-float ring-2 ring-[color:var(--gold)]/60 shadow-[0_0_60px_var(--gold)]" style={{ background: "radial-gradient(circle at 30% 30%, #ffffff, #f3e9c9 70%, #e6d28a 100%)" }}>
                <img src={logo} alt="Wadi Groups Logo" width={260} height={260} className="h-[78%] w-[78%] object-contain" />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* LEADERSHIP */}
      <section className="container mx-auto px-6 py-24">
        <SectionHeading eyebrow="Leadership" title={<>A Word from our <span className="gradient-gold-text">Chairman</span></>} />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative max-w-3xl mx-auto glass-strong rounded-3xl p-8 md:p-12 ring-gold-border text-center"
        >
          <div className="font-display text-6xl gradient-gold-text leading-none mb-4">“</div>
          <p className="text-lg md:text-xl text-foreground/90 italic leading-relaxed">
            At WADI GROUPS, we believe true excellence is built on integrity, vision and an unwavering commitment to our partners. Every company under our group exists to deliver value that endures — across industries, generations and borders.
          </p>
          <div className="mt-8 inline-flex flex-col items-center">
            <div className="h-px w-16 gradient-gold-bg mb-4" />
            <div className="font-display text-2xl gradient-gold-text">Dr. Irfan Ahmed</div>
            <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground mt-1">Chairman & Founder</div>
          </div>
        </motion.div>
      </section>

      {/* ABOUT */}
      <section className="container mx-auto px-6 py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <SectionHeading eyebrow="About" title={<>A Legacy of <span className="gradient-gold-text">Excellence</span></>} subtitle="WADI GROUPS stands at the intersection of vision and execution — a diversified UAE business group delivering excellence across four pillars of the modern economy." center={false} />
            <div className="space-y-4 text-muted-foreground">
              <p>From healthcare to construction, trading to global logistics, our companies are united by a single belief: that uncompromising quality, ethical partnership and innovative thinking create enduring value.</p>
              <p>Headquartered in Dubai, we operate across the UAE and the wider Middle East with the agility of a modern enterprise and the discipline of a heritage group.</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: "Vision", text: "Multi-industry leadership across the UAE and the region." },
              { label: "Mission", text: "Deliver excellence, innovation and lasting value." },
              { label: "Values", text: "Integrity, quality, partnership, vision." },
              { label: "Reach", text: "Headquartered in Dubai, serving globally." },
            ].map((b, i) => (
              <motion.div
                key={b.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass rounded-2xl p-6 ring-gold-border"
              >
                <div className="text-xs uppercase tracking-widest text-gold mb-2">{b.label}</div>
                <p className="text-sm">{b.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* COMPANIES */}
      <section className="container mx-auto px-6 py-24">
        <SectionHeading eyebrow="Our Group" title={<>Group <span className="gradient-gold-text">Companies</span></>} subtitle="Four specialised companies, one unified standard of excellence." />
        <div className="grid md:grid-cols-2 gap-6">
          {companies.map((c, i) => <CompanyCard key={c.slug} c={c} index={i} />)}
        </div>
      </section>

      {/* STATS */}
      <section className="relative py-24">
        <div className="absolute inset-0 gradient-gold-bg opacity-[0.06]" />
        <div className="relative container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-6">
            {stats.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass rounded-2xl p-6 text-center ring-gold-border"
              >
                <div className="font-display text-4xl md:text-5xl gradient-gold-text">{s.value}</div>
                <div className="mt-2 text-xs uppercase tracking-widest text-muted-foreground">{s.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY US */}
      <section className="container mx-auto px-6 py-24">
        <SectionHeading eyebrow="Why Choose Us" title={<>Built on <span className="gradient-gold-text">Trust</span></>} subtitle="The principles that define every project, partnership and decision." />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {whyUs.map((w, i) => (
            <motion.div
              key={w.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ y: -6 }}
              className="glass rounded-2xl p-6 ring-gold-border group"
            >
              <div className="h-12 w-12 rounded-xl gradient-gold-bg grid place-items-center text-primary-foreground mb-4 group-hover:glow-gold transition">
                <w.icon size={22} />
              </div>
              <h3 className="font-display text-xl mb-1">{w.title}</h3>
              <p className="text-sm text-muted-foreground">{w.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* TIMELINE */}
      <section className="container mx-auto px-6 py-24">
        <SectionHeading eyebrow="Journey" title={<>Corporate <span className="gradient-gold-text">Timeline</span></>} />
        <div className="relative max-w-3xl mx-auto">
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px gradient-gold-bg opacity-50" />
          {timeline.map((t, i) => (
            <motion.div
              key={t.title}
              initial={{ opacity: 0, x: i % 2 ? 30 : -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className={`relative mb-10 md:w-1/2 ${i % 2 ? "md:ml-auto md:pl-12" : "md:pr-12 md:text-right"} pl-12 md:pl-0`}
            >
              <div className={`absolute top-2 h-4 w-4 rounded-full gradient-gold-bg glow-gold ${i % 2 ? "left-2 md:-left-2" : "left-2 md:-right-2"}`} />
              <div className="glass rounded-2xl p-6 ring-gold-border">
                <div className="text-xs uppercase tracking-widest text-gold mb-1">{t.year}</div>
                <h3 className="font-display text-xl mb-1">{t.title}</h3>
                <p className="text-sm text-muted-foreground">{t.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>


      {/* CTA */}
      <section className="container mx-auto px-6 py-24">
        <div className="relative overflow-hidden glass-strong rounded-3xl p-12 md:p-16 text-center ring-gold-border">
          <GoldParticles count={20} />
          <SectionHeading eyebrow="Partner with us" title={<>Let's Build <span className="gradient-gold-text">Together</span></>} subtitle="Whether you're an investor, supplier or future partner — we'd love to connect." />
          <div className="flex flex-wrap justify-center gap-4">
            <a href="https://wa.me/971554891800" target="_blank" rel="noreferrer" className="btn-gold rounded-full px-7 py-3 text-sm">WhatsApp Us</a>
            <Link to="/contact" className="btn-ghost-gold rounded-full px-7 py-3 text-sm">Contact Form</Link>
          </div>
        </div>
      </section>
    </>
  );
}
