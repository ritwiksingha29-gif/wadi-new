import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "motion/react";
import { Mail, MapPin, MessageCircle, Phone, Check, Clock } from "lucide-react";
import { SectionHeading } from "@/components/site/SectionHeading";
import { GoldParticles } from "@/components/site/GoldParticles";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — WADI GROUPS" },
      { name: "description", content: "Get in touch with WADI GROUPS. Reach our Dubai headquarters by phone, WhatsApp or email." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);
  return (
    <>
      <section className="relative py-24 overflow-hidden">
        <GoldParticles count={18} />
        <div className="container mx-auto px-6 text-center max-w-3xl">
          <div className="text-xs uppercase tracking-[0.35em] text-gold mb-4">Contact</div>
          <h1 className="font-display text-5xl md:text-6xl">Let's <span className="gradient-gold-text">Connect</span></h1>
          <p className="mt-6 text-lg text-muted-foreground">
            Reach our Dubai headquarters for business enquiries, partnerships and opportunities.
          </p>
        </div>
      </section>

      <section className="container mx-auto px-6 pb-12">
        <div className="grid md:grid-cols-4 gap-5">
          {[
            { Icon: MessageCircle, label: "WhatsApp", text: "+971 55 489 1800", href: "https://wa.me/971554891800" },
            { Icon: Phone, label: "Phone", text: "+971 55 489 1800", href: "tel:+971554891800" },
            { Icon: Mail, label: "Email", text: "info@wadialnaam.com", href: "mailto:info@wadialnaam.com" },
            { Icon: MapPin, label: "Location", text: "Al Quoz Third Block - B Office 311, Dubai, UAE" },
          ].map(({ Icon, label, text, href }, i) => (
            <motion.div key={label} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="glass rounded-2xl p-6 ring-gold-border">
              <div className="h-11 w-11 rounded-xl gradient-gold-bg grid place-items-center text-primary-foreground mb-3">
                <Icon size={18} />
              </div>
              <div className="text-xs uppercase tracking-widest text-gold mb-1">{label}</div>
              {href ? <a href={href} target="_blank" rel="noreferrer" className="text-sm hover:text-gold">{text}</a> : <p className="text-sm">{text}</p>}
            </motion.div>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-6 py-12">
        <div className="grid lg:grid-cols-2 gap-8">
          <div className="glass-strong rounded-3xl p-8 md:p-10 ring-gold-border">
            <SectionHeading eyebrow="Send a Message" title={<>Get in <span className="gradient-gold-text">Touch</span></>} center={false} />
            {sent ? (
              <div className="text-center py-10">
                <div className="h-14 w-14 mx-auto rounded-full gradient-gold-bg grid place-items-center text-primary-foreground mb-4 glow-gold">
                  <Check size={24} />
                </div>
                <h3 className="font-display text-2xl gradient-gold-text">Message Sent</h3>
                <p className="text-muted-foreground mt-2 text-sm">We will respond to your message shortly.</p>
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="space-y-4">
                <Input label="Name" name="name" required />
                <Input label="Email" name="email" type="email" required />
                <Input label="Subject" name="subject" required />
                <div>
                  <label className="text-xs uppercase tracking-widest text-gold mb-2 block">Message</label>
                  <textarea required maxLength={1500} rows={5} className="w-full glass rounded-xl px-4 py-3 text-sm bg-transparent outline-none focus:ring-2 focus:ring-[color:var(--gold)]/40" />
                </div>
                <button type="submit" className="btn-gold rounded-full px-8 py-3 text-sm font-medium w-full">Send Message</button>
              </form>
            )}
          </div>

          <div className="space-y-6">
            <div className="glass rounded-3xl overflow-hidden ring-gold-border h-80">
              <iframe
                title="WADI GROUPS Location"
                src="https://www.google.com/maps?q=Al+Quoz+Third,+Dubai,+UAE&output=embed"
                width="100%"
                height="100%"
                style={{ border: 0, filter: "invert(0.92) hue-rotate(180deg) saturate(0.8)" }}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
            <div className="glass rounded-3xl p-6 ring-gold-border">
              <div className="flex items-center gap-3 mb-3">
                <Clock size={18} className="text-gold" />
                <h3 className="font-display text-xl">Business Hours</h3>
              </div>
              <div className="text-sm text-muted-foreground space-y-1">
                <div className="flex justify-between"><span>Sunday – Thursday</span><span className="text-foreground">9:00 AM – 6:00 PM</span></div>
                <div className="flex justify-between"><span>Friday</span><span className="text-foreground">Closed</span></div>
                <div className="flex justify-between"><span>Saturday</span><span className="text-foreground">10:00 AM – 2:00 PM</span></div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function Input({ label, name, type = "text", required }: { label: string; name: string; type?: string; required?: boolean }) {
  return (
    <div>
      <label className="text-xs uppercase tracking-widest text-gold mb-2 block">{label}</label>
      <input name={name} type={type} required={required} maxLength={200} className="w-full glass rounded-xl px-4 py-3 text-sm bg-transparent outline-none focus:ring-2 focus:ring-[color:var(--gold)]/40" />
    </div>
  );
}
