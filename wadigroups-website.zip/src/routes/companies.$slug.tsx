import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { motion } from "motion/react";
import { ArrowLeft, Check, Mail, MapPin, Phone } from "lucide-react";
import { companies, companyContent } from "@/lib/companies";
import { SectionHeading } from "@/components/site/SectionHeading";
import { GoldParticles } from "@/components/site/GoldParticles";

export const Route = createFileRoute("/companies/$slug")({
  head: ({ params }) => {
    const c = companies.find((x) => x.slug === params.slug);
    return {
      meta: [
        { title: c ? `${c.name} — WADI GROUPS` : "Company — WADI GROUPS" },
        { name: "description", content: c?.description ?? "WADI GROUPS subsidiary." },
        { property: "og:image", content: c?.image },
      ],
    };
  },
  component: CompanyPage,
  notFoundComponent: () => (
    <div className="container mx-auto px-6 py-24 text-center">
      <h1 className="font-display text-3xl">Company not found</h1>
      <Link to="/companies" className="mt-6 inline-flex btn-gold rounded-full px-6 py-2 text-sm">View all companies</Link>
    </div>
  ),
});

function CompanyPage() {
  const { slug } = Route.useParams();
  const company = companies.find((c) => c.slug === slug);
  if (!company) throw notFound();
  const content = companyContent[slug];

  return (
    <>
      <section className="relative min-h-[70vh] overflow-hidden">
        <img src={company.image} alt={company.name} className="absolute inset-0 h-full w-full object-cover opacity-35" />
        <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/70 to-background" />
        <GoldParticles count={20} />
        <div className="relative container mx-auto px-6 py-24 min-h-[70vh] flex flex-col justify-end">
          <Link to="/companies" className="inline-flex items-center gap-2 text-sm text-gold mb-6 hover:underline">
            <ArrowLeft size={16} /> All Companies
          </Link>
          <div className="text-xs uppercase tracking-[0.3em] text-gold mb-3">{company.industry}</div>
          <h1 className="font-display text-4xl md:text-6xl max-w-4xl">{company.name}</h1>
          <p className="mt-4 text-xl text-muted-foreground italic">{content.tagline}</p>
        </div>
      </section>

      <section className="container mx-auto px-6 py-20">
        <div className="grid lg:grid-cols-3 gap-6">
          {[
            { label: "Overview", text: content.overview },
            { label: "Vision", text: content.vision },
            { label: "Mission", text: content.mission },
          ].map((b, i) => (
            <motion.div key={b.label} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="glass rounded-2xl p-8 ring-gold-border">
              <div className="text-xs uppercase tracking-widest text-gold mb-3">{b.label}</div>
              <p className="text-sm text-muted-foreground">{b.text}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-6 py-20">
        <SectionHeading eyebrow="Capabilities" title={<>Services & <span className="gradient-gold-text">Solutions</span></>} />
        <div className="grid md:grid-cols-2 gap-5">
          {content.services.map((s, i) => (
            <motion.div key={s.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.08 }} className="glass rounded-2xl p-6 ring-gold-border flex gap-4">
              <div className="h-10 w-10 shrink-0 rounded-xl gradient-gold-bg grid place-items-center text-primary-foreground">
                <Check size={18} />
              </div>
              <div>
                <h3 className="font-display text-xl mb-1">{s.title}</h3>
                <p className="text-sm text-muted-foreground">{s.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-6 py-20">
        <div className="glass-strong rounded-3xl p-10 md:p-14 ring-gold-border">
          <SectionHeading eyebrow="Contact" title={<>Get in <span className="gradient-gold-text">Touch</span></>} />
          <div className="grid md:grid-cols-3 gap-6 max-w-3xl mx-auto">
            {[
              { Icon: MapPin, label: "Location", text: "Al Quoz Third Block - B Office 311, Dubai, UAE" },
              { Icon: Phone, label: "Phone", text: "+971 55 489 1800", href: "tel:+971554891800" },
              { Icon: Mail, label: "Email", text: "info@wadialnaam.com", href: "mailto:info@wadialnaam.com" },
            ].map(({ Icon, label, text, href }) => (
              <div key={label} className="text-center">
                <div className="h-12 w-12 mx-auto rounded-xl gradient-gold-bg grid place-items-center text-primary-foreground mb-3">
                  <Icon size={20} />
                </div>
                <div className="text-xs uppercase tracking-widest text-gold mb-1">{label}</div>
                {href ? <a href={href} className="text-sm hover:text-gold">{text}</a> : <p className="text-sm">{text}</p>}
              </div>
            ))}
          </div>
          <div className="mt-10 flex justify-center gap-4">
            <a href="https://wa.me/971554891800" target="_blank" rel="noreferrer" className="btn-gold rounded-full px-7 py-3 text-sm">WhatsApp</a>
            <Link to="/contact" className="btn-ghost-gold rounded-full px-7 py-3 text-sm">Contact Form</Link>
          </div>
        </div>
      </section>
    </>
  );
}
