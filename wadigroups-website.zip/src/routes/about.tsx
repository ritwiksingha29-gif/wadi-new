import { createFileRoute } from "@tanstack/react-router";
import { motion } from "motion/react";
import { SectionHeading } from "@/components/site/SectionHeading";
import { GoldParticles } from "@/components/site/GoldParticles";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — WADI GROUPS" },
      { name: "description", content: "Discover the vision, mission and journey of WADI GROUPS — a premier UAE multi-industry business group." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <>
      <section className="relative py-24 overflow-hidden">
        <GoldParticles count={18} />
        <div className="container mx-auto px-6 text-center max-w-3xl">
          <div className="text-xs uppercase tracking-[0.35em] text-gold mb-4">About the Group</div>
          <h1 className="font-display text-5xl md:text-6xl"><span className="gradient-gold-text">WADI GROUPS</span></h1>
          <p className="mt-6 text-lg text-muted-foreground">
            A diversified UAE business group built on vision, trust and uncompromising standards across four core industries.
          </p>
        </div>
      </section>

      <section className="container mx-auto px-6 py-16">
        <div className="grid lg:grid-cols-3 gap-6">
          {[
            { title: "Our Vision", text: "To be recognised as the UAE's most trusted multi-industry business group, leading with integrity, innovation and excellence across every sector we serve." },
            { title: "Our Mission", text: "Deliver world-class products, services and solutions that empower clients, strengthen partnerships and shape the future of the regional economy." },
            { title: "Our Values", text: "Integrity above all. Quality without compromise. Partnership over transaction. Vision beyond the horizon." },
          ].map((b, i) => (
            <motion.div key={b.title} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="glass rounded-2xl p-8 ring-gold-border">
              <h3 className="font-display text-2xl mb-3 gradient-gold-text">{b.title}</h3>
              <p className="text-sm text-muted-foreground">{b.text}</p>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="container mx-auto px-6 py-24">
        <SectionHeading eyebrow="Journey" title={<>Growth, Diversification & <span className="gradient-gold-text">Future</span></>} />
        <div className="max-w-3xl mx-auto space-y-6 text-muted-foreground">
          <p>From its founding in Dubai, WADI GROUPS has grown into a multi-sector enterprise spanning Healthcare, Trading, Import Export and Contracting. Each company within the group operates with sectoral expertise, while drawing on the shared resources, governance and standards of a unified holding structure.</p>
          <p>Our growth has been deliberate. Every new venture, every expansion has been driven by a strategic vision — to participate in the industries that build modern economies and improve modern lives. Healthcare equipment that saves lives. Trade that connects markets. Logistics that powers global commerce. Construction that shapes the cities of tomorrow.</p>
          <p>As we look ahead, we continue to invest in talent, technology and partnerships that will define the next chapter of our story — not only across the UAE, but throughout the Middle East and the world.</p>
        </div>
      </section>

      <section className="container mx-auto px-6 pb-24">
        <SectionHeading eyebrow="Leadership" title={<>Message from the <span className="gradient-gold-text">Chairman</span></>} />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative max-w-3xl mx-auto glass-strong rounded-3xl p-8 md:p-12 ring-gold-border text-center"
        >
          <div className="font-display text-6xl gradient-gold-text leading-none mb-4">“</div>
          <p className="text-lg md:text-xl text-foreground/90 italic leading-relaxed">
            Our journey has always been guided by a single principle — to build with purpose. At WADI GROUPS, we don't simply grow companies; we craft institutions that stand for trust, quality and the prosperity of every community we serve.
          </p>
          <div className="mt-8 inline-flex flex-col items-center">
            <div className="h-px w-16 gradient-gold-bg mb-4" />
            <div className="font-display text-2xl gradient-gold-text">Dr. Irfan Ahmed</div>
            <div className="text-xs uppercase tracking-[0.3em] text-muted-foreground mt-1">Chairman & Founder</div>
          </div>
        </motion.div>
      </section>

    </>
  );
}
