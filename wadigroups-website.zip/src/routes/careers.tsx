import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "motion/react";
import { Check, Upload } from "lucide-react";
import { SectionHeading } from "@/components/site/SectionHeading";
import { GoldParticles } from "@/components/site/GoldParticles";

export const Route = createFileRoute("/careers")({
  head: () => ({
    meta: [
      { title: "Careers — WADI GROUPS" },
      { name: "description", content: "Join WADI GROUPS. Submit your CV to be considered for future opportunities across our group of companies." },
    ],
  }),
  component: Careers,
});

function Careers() {
  const [submitted, setSubmitted] = useState(false);
  const [fileName, setFileName] = useState<string>("");

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Static portfolio — submission stub. Backend integration would email info@wadialnaam.com.
    setSubmitted(true);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <>
      <section className="relative py-24 overflow-hidden">
        <GoldParticles count={20} />
        <div className="container mx-auto px-6 text-center max-w-3xl">
          <div className="text-xs uppercase tracking-[0.35em] text-gold mb-4">Careers</div>
          <h1 className="font-display text-5xl md:text-6xl">Join <span className="gradient-gold-text">WADI GROUPS</span></h1>
          <p className="mt-6 text-lg text-muted-foreground">
            We are always looking for talented professionals to become part of our growing organization across Healthcare, Trading, Import Export, and Contracting sectors.
          </p>
        </div>
      </section>

      <section className="container mx-auto px-6 pb-24">
        <div className="max-w-3xl mx-auto">
          {submitted ? (
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="glass-strong rounded-3xl p-12 text-center ring-gold-border">
              <div className="h-16 w-16 mx-auto rounded-full gradient-gold-bg grid place-items-center text-primary-foreground mb-6 glow-gold">
                <Check size={28} />
              </div>
              <h2 className="font-display text-3xl mb-3 gradient-gold-text">Application Received</h2>
              <p className="text-muted-foreground">
                Thank you for your interest in WADI GROUPS. Your application has been successfully submitted. Our recruitment team will review your profile and contact you if a suitable opportunity becomes available.
              </p>
            </motion.div>
          ) : (
            <form onSubmit={onSubmit} className="glass-strong rounded-3xl p-8 md:p-10 ring-gold-border space-y-5">
              <SectionHeading eyebrow="Apply" title={<>Career <span className="gradient-gold-text">Application</span></>} subtitle="Submit your details below — we will reach out when an aligned opportunity arises." />
              <div className="grid md:grid-cols-2 gap-5">
                <Field label="Full Name" name="fullName" required />
                <Field label="Phone Number" name="phone" type="tel" required />
                <Field label="Email Address" name="email" type="email" required />
                <Field label="Nationality" name="nationality" required />
                <Field label="Current Location" name="location" required />
                <Field label="Position Applying For" name="position" required />
                <Field label="Years of Experience" name="experience" type="number" required />
                <Field label="Education Qualification" name="education" required />
              </div>

              <div>
                <label className="text-xs uppercase tracking-widest text-gold mb-2 block">Upload CV / Resume</label>
                <label className="glass rounded-xl px-4 py-4 flex items-center gap-3 cursor-pointer hover:bg-white/5 transition">
                  <Upload size={18} className="text-gold" />
                  <span className="text-sm text-muted-foreground">{fileName || "Choose file (PDF, DOC, DOCX)"}</span>
                  <input
                    type="file"
                    name="cv"
                    accept=".pdf,.doc,.docx"
                    required
                    className="hidden"
                    onChange={(e) => setFileName(e.target.files?.[0]?.name ?? "")}
                  />
                </label>
              </div>

              <div>
                <label className="text-xs uppercase tracking-widest text-gold mb-2 block">Cover Message</label>
                <textarea
                  name="message"
                  rows={5}
                  required
                  maxLength={1500}
                  className="w-full glass rounded-xl px-4 py-3 text-sm bg-transparent outline-none focus:ring-2 focus:ring-[color:var(--gold)]/40 placeholder:text-muted-foreground"
                  placeholder="Tell us about yourself and why you'd like to join WADI GROUPS..."
                />
              </div>

              <button type="submit" className="btn-gold rounded-full px-8 py-3 text-sm font-medium w-full md:w-auto">
                Submit Application
              </button>
            </form>
          )}
        </div>
      </section>
    </>
  );
}

function Field({ label, name, type = "text", required }: { label: string; name: string; type?: string; required?: boolean }) {
  return (
    <div>
      <label className="text-xs uppercase tracking-widest text-gold mb-2 block">{label}</label>
      <input
        name={name}
        type={type}
        required={required}
        maxLength={200}
        className="w-full glass rounded-xl px-4 py-3 text-sm bg-transparent outline-none focus:ring-2 focus:ring-[color:var(--gold)]/40 placeholder:text-muted-foreground"
      />
    </div>
  );
}
