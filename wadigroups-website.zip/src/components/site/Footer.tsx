import { Link } from "@tanstack/react-router";
import { MapPin, Mail, Phone, Globe, Camera, Briefcase } from "lucide-react";
import logo from "@/assets/wadi-logo.png";

export function Footer() {
  return (
    <footer className="relative mt-32 border-t border-[color:var(--gold)]/20 bg-[oklch(0.10_0.005_60)]">
      <div className="absolute inset-x-0 -top-px h-px gradient-gold-bg opacity-60" />
      <div className="container mx-auto px-6 py-16 grid gap-12 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <img src={logo} alt="Wadi Groups" width={48} height={48} className="h-12 w-12" loading="lazy" />
            <span className="font-display text-xl gradient-gold-text">WADI GROUPS</span>
          </div>
          <p className="text-sm text-muted-foreground">
            A premier UAE business group operating across Healthcare, Trading, Import Export and Contracting industries.
          </p>
          <div className="flex gap-3 mt-6">
            {[Globe, Camera, Briefcase].map((Icon, i) => (
              <a key={i} href="#" className="glass h-9 w-9 grid place-items-center rounded-full hover:glow-gold transition">
                <Icon size={16} className="text-gold" />
              </a>
            ))}
          </div>
        </div>
        <div>
          <h4 className="text-gold text-sm uppercase tracking-widest mb-4">Our Companies</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/companies/medical" className="hover:text-gold">Wadi Alhaya Medical Equipment LLC</Link></li>
            <li><Link to="/companies/trading" className="hover:text-gold">Wadi Middle East Trading LLC</Link></li>
            <li><Link to="/companies/import-export" className="hover:text-gold">Wadi Middle East Import Export LLC</Link></li>
            <li><Link to="/companies/contracting" className="hover:text-gold">Wadi Al Naam Contracting LLC</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-gold text-sm uppercase tracking-widest mb-4">Quick Links</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/" className="hover:text-gold">Home</Link></li>
            <li><Link to="/about" className="hover:text-gold">About</Link></li>
            <li><Link to="/companies" className="hover:text-gold">Companies</Link></li>
            <li><Link to="/careers" className="hover:text-gold">Careers</Link></li>
            <li><Link to="/contact" className="hover:text-gold">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-gold text-sm uppercase tracking-widest mb-4">Contact</h4>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex gap-2"><MapPin size={16} className="text-gold mt-0.5 shrink-0" /> Al Quoz Third Block - B Office 311, Dubai, UAE</li>
            <li className="flex gap-2"><Phone size={16} className="text-gold mt-0.5" /> <a href="tel:+971554891800" className="hover:text-gold">+971 55 489 1800</a></li>
            <li className="flex gap-2"><Mail size={16} className="text-gold mt-0.5" /> <a href="mailto:info@wadialnaam.com" className="hover:text-gold">info@wadialnaam.com</a></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-[color:var(--gold)]/15 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} WADI GROUPS. All rights reserved.
      </div>
    </footer>
  );
}
