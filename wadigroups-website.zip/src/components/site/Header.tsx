import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";
import logo from "@/assets/wadi-logo.png";

const nav = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/companies", label: "Companies" },
  { to: "/careers", label: "Careers" },
  { to: "/contact", label: "Contact" },
];

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <div className="glass-strong border-b border-[color:var(--gold)]/20">
        <div className="container mx-auto flex items-center justify-between px-6 py-3">
          <Link to="/" className="flex items-center gap-2 sm:gap-3 group min-w-0">
            <span className="grid place-items-center h-9 w-9 sm:h-12 sm:w-12 rounded-full bg-white ring-2 ring-[color:var(--gold)]/60 shadow-[0_0_18px_var(--gold)] p-1 shrink-0">
              <img src={logo} alt="Wadi Groups" width={44} height={44} className="h-full w-full object-contain" />
            </span>
            <div className="leading-tight min-w-0">
              <div className="font-display text-base sm:text-xl tracking-wide gradient-gold-text truncate">WADI GROUPS</div>
              <div className="hidden sm:block text-[10px] uppercase tracking-[0.25em] text-muted-foreground">United Arab Emirates</div>
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            {nav.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                className="text-sm uppercase tracking-widest text-foreground/80 hover:text-gold transition-colors relative after:absolute after:left-0 after:-bottom-1 after:h-px after:w-0 after:bg-gold after:transition-all hover:after:w-full"
                activeProps={{ className: "text-gold" }}
              >
                {n.label}
              </Link>
            ))}
          </nav>
          <a
            href="https://wa.me/971554891800"
            target="_blank"
            rel="noreferrer"
            className="hidden md:inline-flex btn-gold rounded-full px-5 py-2 text-sm font-medium"
          >
            WhatsApp
          </a>
          <button className="md:hidden text-gold" onClick={() => setOpen(!open)} aria-label="Toggle menu">
            {open ? <X /> : <Menu />}
          </button>
        </div>
        {open && (
          <div className="md:hidden border-t border-[color:var(--gold)]/20 px-6 py-4 flex flex-col gap-4">
            {nav.map((n) => (
              <Link key={n.to} to={n.to} className="text-sm uppercase tracking-widest" onClick={() => setOpen(false)}>
                {n.label}
              </Link>
            ))}
            <a href="https://wa.me/971554891800" className="btn-gold rounded-full px-5 py-2 text-sm text-center">WhatsApp</a>
          </div>
        )}
      </div>
    </header>
  );
}
