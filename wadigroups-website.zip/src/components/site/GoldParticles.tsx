export function GoldParticles({ count = 24 }: { count?: number }) {
  const particles = Array.from({ length: count });
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {particles.map((_, i) => {
        const size = 2 + Math.random() * 4;
        const left = Math.random() * 100;
        const delay = Math.random() * 12;
        const duration = 10 + Math.random() * 14;
        return (
          <span
            key={i}
            className="animate-particle absolute rounded-full"
            style={{
              left: `${left}%`,
              bottom: `-${size}px`,
              width: size,
              height: size,
              background: "var(--gold)",
              boxShadow: "0 0 8px var(--gold)",
              animationDelay: `${delay}s`,
              animationDuration: `${duration}s`,
              opacity: 0.6,
            }}
          />
        );
      })}
    </div>
  );
}
