import { MessageCircle } from "lucide-react";

export function WhatsAppFab() {
  return (
    <a
      href="https://wa.me/971554891800"
      target="_blank"
      rel="noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-6 right-6 z-50 group"
    >
      <span className="absolute inset-0 rounded-full bg-[oklch(0.75_0.18_150)] blur-xl opacity-60 animate-glow-pulse" />
      <span className="relative grid place-items-center h-14 w-14 rounded-full bg-[oklch(0.62_0.18_150)] text-white shadow-lg ring-2 ring-[color:var(--gold)]/40 group-hover:scale-110 transition-transform animate-float">
        <MessageCircle size={24} />
      </span>
    </a>
  );
}
