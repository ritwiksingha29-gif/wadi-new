import { Link } from "@tanstack/react-router";
import { motion } from "motion/react";
import { ArrowUpRight } from "lucide-react";

export interface Company {
  slug: "medical" | "trading" | "import-export" | "contracting";
  name: string;
  industry: string;
  description: string;
  image: string;
}

export function CompanyCard({ c, index }: { c: Company; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="group relative overflow-hidden rounded-2xl glass ring-gold-border"
    >
      <div className="relative h-56 overflow-hidden">
        <img src={c.image} alt={c.name} className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        <div className="absolute top-4 left-4 glass-strong rounded-full px-3 py-1 text-[10px] uppercase tracking-widest text-gold">
          {c.industry}
        </div>
      </div>
      <div className="p-6">
        <h3 className="font-display text-2xl mb-2 group-hover:text-gold transition">{c.name}</h3>
        <p className="text-sm text-muted-foreground mb-5">{c.description}</p>
        <Link
          to="/companies/$slug"
          params={{ slug: c.slug }}
          className="inline-flex items-center gap-2 text-sm text-gold group/btn"
        >
          Learn More
          <ArrowUpRight size={16} className="transition-transform group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5" />
        </Link>
      </div>
    </motion.div>
  );
}
