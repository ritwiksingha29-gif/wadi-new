import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { S as SectionHeading } from "./SectionHeading-Cpey6AmV.mjs";
import { C as CompanyCard } from "./CompanyCard-J5Vr_q9t.mjs";
import { c as companies } from "./router-Bz5zk8E0.mjs";
import "../_libs/framer-motion.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/lucide-react.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
function CompaniesIndex() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "container mx-auto px-6 py-24", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Our Group", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      "Companies of ",
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "WADI GROUPS" })
    ] }), subtitle: "Four specialised companies operating across the most vital industries of the UAE economy." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid md:grid-cols-2 gap-6", children: companies.map((c, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(CompanyCard, { c, index: i }, c.slug)) })
  ] });
}
export {
  CompaniesIndex as component
};
