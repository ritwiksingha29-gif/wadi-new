import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { c as companies, l as logo } from "./router-Bz5zk8E0.mjs";
import { C as CompanyCard } from "./CompanyCard-J5Vr_q9t.mjs";
import { S as SectionHeading } from "./SectionHeading-Cpey6AmV.mjs";
import { G as GoldParticles } from "./GoldParticles-CCOquF9w.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import { A as ArrowRight, f as Award, g as Users, S as ShieldCheck, h as Sparkles, T as Trophy, E as Earth, B as Briefcase, i as Building2 } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
const hero = "/assets/hero-dubai-2JUxKW2G.jpg";
const stats = [{
  value: "15+",
  label: "Years of Experience"
}, {
  value: "500+",
  label: "Successful Projects"
}, {
  value: "4",
  label: "Business Sectors"
}, {
  value: "1000+",
  label: "Clients Served"
}, {
  value: "120+",
  label: "Strategic Partners"
}];
const whyUs = [{
  icon: Award,
  title: "Industry Expertise",
  desc: "Decades of cross-sector mastery."
}, {
  icon: Users,
  title: "Professional Team",
  desc: "World-class talent across all divisions."
}, {
  icon: ShieldCheck,
  title: "Trusted Reputation",
  desc: "Built on integrity and delivery."
}, {
  icon: Sparkles,
  title: "Innovation",
  desc: "Modern thinking, future-ready solutions."
}, {
  icon: Trophy,
  title: "Quality Assurance",
  desc: "Uncompromising standards at every step."
}, {
  icon: Earth,
  title: "UAE Market Leadership",
  desc: "Deep roots, global reach."
}, {
  icon: Briefcase,
  title: "Long-Term Partnerships",
  desc: "Relationships built to last."
}, {
  icon: Building2,
  title: "Multi-Industry Scale",
  desc: "Four core sectors under one vision."
}];
const timeline = [{
  year: "Foundation",
  title: "Group Established",
  desc: "WADI GROUPS founded in Dubai with a vision of multi-industry excellence."
}, {
  year: "Expansion",
  title: "Healthcare Division",
  desc: "Launched Wadi Alhaya Medical Equipment to serve UAE's healthcare sector."
}, {
  year: "Diversification",
  title: "Trading & Logistics",
  desc: "Expanded into trading, import-export and international logistics."
}, {
  year: "Growth",
  title: "Contracting Division",
  desc: "Wadi Al Naam Contracting joins the group, entering construction."
}, {
  year: "Future",
  title: "Regional Leadership",
  desc: "Continued expansion across the GCC and emerging international markets."
}];
function Home() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative min-h-[92vh] overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: hero, alt: "Dubai skyline", className: "h-full w-full object-cover opacity-40" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-b from-background/60 via-background/70 to-background" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(GoldParticles, { count: 36 }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative container mx-auto px-6 pt-24 pb-16 md:pt-16 md:pb-24 grid lg:grid-cols-2 gap-10 lg:gap-12 items-center min-h-[92vh]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
            opacity: 0,
            y: 20
          }, animate: {
            opacity: 1,
            y: 0
          }, transition: {
            duration: 0.7
          }, className: "inline-flex items-center gap-3 glass rounded-full px-4 py-1.5 text-[10px] sm:text-xs uppercase tracking-[0.3em] text-gold mb-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "h-1.5 w-1.5 rounded-full bg-gold animate-glow-pulse" }),
            " United Arab Emirates"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.h1, { initial: {
            opacity: 0,
            y: 30
          }, animate: {
            opacity: 1,
            y: 0
          }, transition: {
            duration: 0.8,
            delay: 0.1
          }, className: "font-display text-4xl sm:text-5xl md:text-7xl leading-[0.95]", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "WADI" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: "GROUPS" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(motion.p, { initial: {
            opacity: 0
          }, animate: {
            opacity: 1
          }, transition: {
            delay: 0.4
          }, className: "mt-6 max-w-xl text-base sm:text-lg text-muted-foreground", children: "Building Excellence Across Healthcare, Trading, Import Export & Contracting Industries in the UAE." }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
            opacity: 0,
            y: 10
          }, animate: {
            opacity: 1,
            y: 0
          }, transition: {
            delay: 0.55
          }, className: "mt-8 flex flex-wrap gap-3 sm:gap-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/companies", className: "btn-gold rounded-full px-5 sm:px-7 py-3 text-sm font-medium inline-flex items-center gap-2", children: [
              "Explore Companies ",
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { size: 16 })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: "btn-ghost-gold rounded-full px-5 sm:px-7 py-3 text-sm font-medium", children: "Contact Us" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { initial: {
            opacity: 0
          }, animate: {
            opacity: 1
          }, transition: {
            delay: 0.8
          }, className: "mt-10 grid sm:grid-cols-2 gap-3", children: companies.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "glass rounded-lg px-4 py-3 text-sm", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gold mr-2", children: "◆" }),
            c.name
          ] }, c.slug)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative flex items-center justify-center order-first lg:order-last", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
          opacity: 0,
          scale: 0.8
        }, animate: {
          opacity: 1,
          scale: 1
        }, transition: {
          duration: 1
        }, className: "relative w-[min(85vw,420px)] aspect-square", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 rounded-full animate-glow-pulse", style: {
            background: "radial-gradient(circle, oklch(0.82 0.15 85 / 0.35), transparent 70%)"
          } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-[4%] rounded-full border border-[color:var(--gold)]/40 animate-spin-slow" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-[12%] rounded-full border border-[color:var(--gold)]/20 animate-spin-slow", style: {
            animationDuration: "40s",
            animationDirection: "reverse"
          } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-[20%] rounded-full grid place-items-center animate-float ring-2 ring-[color:var(--gold)]/60 shadow-[0_0_60px_var(--gold)]", style: {
            background: "radial-gradient(circle at 30% 30%, #ffffff, #f3e9c9 70%, #e6d28a 100%)"
          }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logo, alt: "Wadi Groups Logo", width: 260, height: 260, className: "h-[78%] w-[78%] object-contain" }) })
        ] }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "container mx-auto px-6 py-24", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Leadership", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "A Word from our ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Chairman" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        y: 20
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true
      }, className: "relative max-w-3xl mx-auto glass-strong rounded-3xl p-8 md:p-12 ring-gold-border text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-6xl gradient-gold-text leading-none mb-4", children: "“" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg md:text-xl text-foreground/90 italic leading-relaxed", children: "At WADI GROUPS, we believe true excellence is built on integrity, vision and an unwavering commitment to our partners. Every company under our group exists to deliver value that endures — across industries, generations and borders." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 inline-flex flex-col items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px w-16 gradient-gold-bg mb-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-2xl gradient-gold-text", children: "Dr. Irfan Ahmed" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-[0.3em] text-muted-foreground mt-1", children: "Chairman & Founder" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "container mx-auto px-6 py-24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid lg:grid-cols-2 gap-12 items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "About", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          "A Legacy of ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Excellence" })
        ] }), subtitle: "WADI GROUPS stands at the intersection of vision and execution — a diversified UAE business group delivering excellence across four pillars of the modern economy.", center: false }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4 text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "From healthcare to construction, trading to global logistics, our companies are united by a single belief: that uncompromising quality, ethical partnership and innovative thinking create enduring value." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Headquartered in Dubai, we operate across the UAE and the wider Middle East with the agility of a modern enterprise and the discipline of a heritage group." })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-4", children: [{
        label: "Vision",
        text: "Multi-industry leadership across the UAE and the region."
      }, {
        label: "Mission",
        text: "Deliver excellence, innovation and lasting value."
      }, {
        label: "Values",
        text: "Integrity, quality, partnership, vision."
      }, {
        label: "Reach",
        text: "Headquartered in Dubai, serving globally."
      }].map((b, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        y: 20
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true
      }, transition: {
        delay: i * 0.1
      }, className: "glass rounded-2xl p-6 ring-gold-border", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-widest text-gold mb-2", children: b.label }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm", children: b.text })
      ] }, b.label)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "container mx-auto px-6 py-24", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Our Group", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Group ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Companies" })
      ] }), subtitle: "Four specialised companies, one unified standard of excellence." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid md:grid-cols-2 gap-6", children: companies.map((c, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(CompanyCard, { c, index: i }, c.slug)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative py-24", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 gradient-gold-bg opacity-[0.06]" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative container mx-auto px-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 md:grid-cols-5 gap-6", children: stats.map((s, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        y: 20
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true
      }, transition: {
        delay: i * 0.1
      }, className: "glass rounded-2xl p-6 text-center ring-gold-border", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-4xl md:text-5xl gradient-gold-text", children: s.value }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 text-xs uppercase tracking-widest text-muted-foreground", children: s.label })
      ] }, s.label)) }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "container mx-auto px-6 py-24", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Why Choose Us", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Built on ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Trust" })
      ] }), subtitle: "The principles that define every project, partnership and decision." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-5", children: whyUs.map((w, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        y: 20
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true
      }, transition: {
        delay: i * 0.05
      }, whileHover: {
        y: -6
      }, className: "glass rounded-2xl p-6 ring-gold-border group", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-12 w-12 rounded-xl gradient-gold-bg grid place-items-center text-primary-foreground mb-4 group-hover:glow-gold transition", children: /* @__PURE__ */ jsxRuntimeExports.jsx(w.icon, { size: 22 }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-xl mb-1", children: w.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: w.desc })
      ] }, w.title)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "container mx-auto px-6 py-24", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Journey", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Corporate ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Timeline" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative max-w-3xl mx-auto", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-4 md:left-1/2 top-0 bottom-0 w-px gradient-gold-bg opacity-50" }),
        timeline.map((t, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
          opacity: 0,
          x: i % 2 ? 30 : -30
        }, whileInView: {
          opacity: 1,
          x: 0
        }, viewport: {
          once: true
        }, transition: {
          duration: 0.6
        }, className: `relative mb-10 md:w-1/2 ${i % 2 ? "md:ml-auto md:pl-12" : "md:pr-12 md:text-right"} pl-12 md:pl-0`, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `absolute top-2 h-4 w-4 rounded-full gradient-gold-bg glow-gold ${i % 2 ? "left-2 md:-left-2" : "left-2 md:-right-2"}` }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "glass rounded-2xl p-6 ring-gold-border", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-widest text-gold mb-1", children: t.year }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-xl mb-1", children: t.title }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: t.desc })
          ] })
        ] }, t.title))
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "container mx-auto px-6 py-24", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative overflow-hidden glass-strong rounded-3xl p-12 md:p-16 text-center ring-gold-border", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(GoldParticles, { count: 20 }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Partner with us", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Let's Build ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Together" })
      ] }), subtitle: "Whether you're an investor, supplier or future partner — we'd love to connect." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap justify-center gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://wa.me/971554891800", target: "_blank", rel: "noreferrer", className: "btn-gold rounded-full px-7 py-3 text-sm", children: "WhatsApp Us" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: "btn-ghost-gold rounded-full px-7 py-3 text-sm", children: "Contact Form" })
      ] })
    ] }) })
  ] });
}
export {
  Home as component
};
