import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { S as SectionHeading } from "./SectionHeading-Cpey6AmV.mjs";
import { G as GoldParticles } from "./GoldParticles-CCOquF9w.mjs";
import { c as MessageCircle, P as Phone, b as Mail, a as MapPin, d as Check, e as Clock } from "../_libs/lucide-react.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function Contact() {
  const [sent, setSent] = reactExports.useState(false);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative py-24 overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(GoldParticles, { count: 18 }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-6 text-center max-w-3xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-[0.35em] text-gold mb-4", children: "Contact" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "font-display text-5xl md:text-6xl", children: [
          "Let's ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Connect" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-lg text-muted-foreground", children: "Reach our Dubai headquarters for business enquiries, partnerships and opportunities." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "container mx-auto px-6 pb-12", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid md:grid-cols-4 gap-5", children: [{
      Icon: MessageCircle,
      label: "WhatsApp",
      text: "+971 55 489 1800",
      href: "https://wa.me/971554891800"
    }, {
      Icon: Phone,
      label: "Phone",
      text: "+971 55 489 1800",
      href: "tel:+971554891800"
    }, {
      Icon: Mail,
      label: "Email",
      text: "info@wadialnaam.com",
      href: "mailto:info@wadialnaam.com"
    }, {
      Icon: MapPin,
      label: "Location",
      text: "Al Quoz Third Block - B Office 311, Dubai, UAE"
    }].map(({
      Icon,
      label,
      text,
      href
    }, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 20
    }, whileInView: {
      opacity: 1,
      y: 0
    }, viewport: {
      once: true
    }, transition: {
      delay: i * 0.08
    }, className: "glass rounded-2xl p-6 ring-gold-border", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-11 w-11 rounded-xl gradient-gold-bg grid place-items-center text-primary-foreground mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { size: 18 }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-widest text-gold mb-1", children: label }),
      href ? /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href, target: "_blank", rel: "noreferrer", className: "text-sm hover:text-gold", children: text }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm", children: text })
    ] }, label)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "container mx-auto px-6 py-12", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid lg:grid-cols-2 gap-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "glass-strong rounded-3xl p-8 md:p-10 ring-gold-border", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Send a Message", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          "Get in ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Touch" })
        ] }), center: false }),
        sent ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-10", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-14 w-14 mx-auto rounded-full gradient-gold-bg grid place-items-center text-primary-foreground mb-4 glow-gold", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { size: 24 }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-2xl gradient-gold-text", children: "Message Sent" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mt-2 text-sm", children: "We will respond to your message shortly." })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: (e) => {
          e.preventDefault();
          setSent(true);
        }, className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { label: "Name", name: "name", required: true }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { label: "Email", name: "email", type: "email", required: true }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { label: "Subject", name: "subject", required: true }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs uppercase tracking-widest text-gold mb-2 block", children: "Message" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { required: true, maxLength: 1500, rows: 5, className: "w-full glass rounded-xl px-4 py-3 text-sm bg-transparent outline-none focus:ring-2 focus:ring-[color:var(--gold)]/40" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "submit", className: "btn-gold rounded-full px-8 py-3 text-sm font-medium w-full", children: "Send Message" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "glass rounded-3xl overflow-hidden ring-gold-border h-80", children: /* @__PURE__ */ jsxRuntimeExports.jsx("iframe", { title: "WADI GROUPS Location", src: "https://www.google.com/maps?q=Al+Quoz+Third,+Dubai,+UAE&output=embed", width: "100%", height: "100%", style: {
          border: 0,
          filter: "invert(0.92) hue-rotate(180deg) saturate(0.8)"
        }, loading: "lazy", referrerPolicy: "no-referrer-when-downgrade" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "glass rounded-3xl p-6 ring-gold-border", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { size: 18, className: "text-gold" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-xl", children: "Business Hours" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-muted-foreground space-y-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sunday – Thursday" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: "9:00 AM – 6:00 PM" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Friday" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: "Closed" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Saturday" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-foreground", children: "10:00 AM – 2:00 PM" })
            ] })
          ] })
        ] })
      ] })
    ] }) })
  ] });
}
function Input({
  label,
  name,
  type = "text",
  required
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs uppercase tracking-widest text-gold mb-2 block", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { name, type, required, maxLength: 200, className: "w-full glass rounded-xl px-4 py-3 text-sm bg-transparent outline-none focus:ring-2 focus:ring-[color:var(--gold)]/40" })
  ] });
}
export {
  Contact as component
};
