import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { H as notFound } from "../_libs/tanstack__router-core.mjs";
import { R as Route, c as companies, a as companyContent } from "./router-Bz5zk8E0.mjs";
import { S as SectionHeading } from "./SectionHeading-Cpey6AmV.mjs";
import { G as GoldParticles } from "./GoldParticles-CCOquF9w.mjs";
import { k as ArrowLeft, d as Check, a as MapPin, P as Phone, b as Mail } from "../_libs/lucide-react.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function CompanyPage() {
  const {
    slug
  } = Route.useParams();
  const company = companies.find((c) => c.slug === slug);
  if (!company) throw notFound();
  const content = companyContent[slug];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative min-h-[70vh] overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: company.image, alt: company.name, className: "absolute inset-0 h-full w-full object-cover opacity-35" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-b from-background/60 via-background/70 to-background" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(GoldParticles, { count: 20 }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative container mx-auto px-6 py-24 min-h-[70vh] flex flex-col justify-end", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/companies", className: "inline-flex items-center gap-2 text-sm text-gold mb-6 hover:underline", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { size: 16 }),
          " All Companies"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-[0.3em] text-gold mb-3", children: company.industry }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-4xl md:text-6xl max-w-4xl", children: company.name }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-xl text-muted-foreground italic", children: content.tagline })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "container mx-auto px-6 py-20", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid lg:grid-cols-3 gap-6", children: [{
      label: "Overview",
      text: content.overview
    }, {
      label: "Vision",
      text: content.vision
    }, {
      label: "Mission",
      text: content.mission
    }].map((b, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 20
    }, whileInView: {
      opacity: 1,
      y: 0
    }, viewport: {
      once: true
    }, transition: {
      delay: i * 0.1
    }, className: "glass rounded-2xl p-8 ring-gold-border", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-widest text-gold mb-3", children: b.label }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: b.text })
    ] }, b.label)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "container mx-auto px-6 py-20", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Capabilities", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Services & ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Solutions" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid md:grid-cols-2 gap-5", children: content.services.map((s, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        y: 20
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true
      }, transition: {
        delay: i * 0.08
      }, className: "glass rounded-2xl p-6 ring-gold-border flex gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-10 w-10 shrink-0 rounded-xl gradient-gold-bg grid place-items-center text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { size: 18 }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-xl mb-1", children: s.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: s.description })
        ] })
      ] }, s.title)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "container mx-auto px-6 py-20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "glass-strong rounded-3xl p-10 md:p-14 ring-gold-border", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Contact", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Get in ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Touch" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid md:grid-cols-3 gap-6 max-w-3xl mx-auto", children: [{
        Icon: MapPin,
        label: "Location",
        text: "Al Quoz Third Block - B Office 311, Dubai, UAE"
      }, {
        Icon: Phone,
        label: "Phone",
        text: "+971 55 489 1800",
        href: "tel:+971554891800"
      }, {
        Icon: Mail,
        label: "Email",
        text: "info@wadialnaam.com",
        href: "mailto:info@wadialnaam.com"
      }].map(({
        Icon,
        label,
        text,
        href
      }) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-12 w-12 mx-auto rounded-xl gradient-gold-bg grid place-items-center text-primary-foreground mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { size: 20 }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-widest text-gold mb-1", children: label }),
        href ? /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href, className: "text-sm hover:text-gold", children: text }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm", children: text })
      ] }, label)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 flex justify-center gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://wa.me/971554891800", target: "_blank", rel: "noreferrer", className: "btn-gold rounded-full px-7 py-3 text-sm", children: "WhatsApp" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: "btn-ghost-gold rounded-full px-7 py-3 text-sm", children: "Contact Form" })
      ] })
    ] }) })
  ] });
}
export {
  CompanyPage as component
};
