import { Q as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { Q as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { c as createRouter, a as createRootRouteWithContext, u as useRouter, L as Link, O as Outlet, H as HeadContent, S as Scripts, b as createFileRoute, l as lazyRouteComponent } from "../_libs/tanstack__react-router.mjs";
import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { X, M as Menu, G as Globe, C as Camera, B as Briefcase, a as MapPin, P as Phone, b as Mail, c as MessageCircle } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
const appCss = "/assets/styles-CHbuLlwS.css";
function reportLovableError(error, context = {}) {
  if (typeof window === "undefined") return;
  window.__lovableEvents?.captureException?.(
    error,
    {
      source: "react_error_boundary",
      route: window.location.pathname,
      ...context
    },
    {
      mechanism: "react_error_boundary",
      handled: false,
      severity: "error"
    }
  );
}
const logo = "/assets/wadi-logo-BwA7TwkY.png";
const nav = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/companies", label: "Companies" },
  { to: "/careers", label: "Careers" },
  { to: "/contact", label: "Contact" }
];
function Header() {
  const [open, setOpen] = reactExports.useState(false);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "fixed top-0 left-0 right-0 z-50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "glass-strong border-b border-[color:var(--gold)]/20", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto flex items-center justify-between px-6 py-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "flex items-center gap-2 sm:gap-3 group min-w-0", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "grid place-items-center h-9 w-9 sm:h-12 sm:w-12 rounded-full bg-white ring-2 ring-[color:var(--gold)]/60 shadow-[0_0_18px_var(--gold)] p-1 shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logo, alt: "Wadi Groups", width: 44, height: 44, className: "h-full w-full object-contain" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "leading-tight min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-base sm:text-xl tracking-wide gradient-gold-text truncate", children: "WADI GROUPS" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "hidden sm:block text-[10px] uppercase tracking-[0.25em] text-muted-foreground", children: "United Arab Emirates" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "hidden md:flex items-center gap-8", children: nav.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        Link,
        {
          to: n.to,
          className: "text-sm uppercase tracking-widest text-foreground/80 hover:text-gold transition-colors relative after:absolute after:left-0 after:-bottom-1 after:h-px after:w-0 after:bg-gold after:transition-all hover:after:w-full",
          activeProps: { className: "text-gold" },
          children: n.label
        },
        n.to
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: "https://wa.me/971554891800",
          target: "_blank",
          rel: "noreferrer",
          className: "hidden md:inline-flex btn-gold rounded-full px-5 py-2 text-sm font-medium",
          children: "WhatsApp"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { className: "md:hidden text-gold", onClick: () => setOpen(!open), "aria-label": "Toggle menu", children: open ? /* @__PURE__ */ jsxRuntimeExports.jsx(X, {}) : /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, {}) })
    ] }),
    open && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "md:hidden border-t border-[color:var(--gold)]/20 px-6 py-4 flex flex-col gap-4", children: [
      nav.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: n.to, className: "text-sm uppercase tracking-widest", onClick: () => setOpen(false), children: n.label }, n.to)),
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://wa.me/971554891800", className: "btn-gold rounded-full px-5 py-2 text-sm text-center", children: "WhatsApp" })
    ] })
  ] }) });
}
function Footer() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("footer", { className: "relative mt-32 border-t border-[color:var(--gold)]/20 bg-[oklch(0.10_0.005_60)]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-x-0 -top-px h-px gradient-gold-bg opacity-60" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-6 py-16 grid gap-12 md:grid-cols-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logo, alt: "Wadi Groups", width: 48, height: 48, className: "h-12 w-12", loading: "lazy" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-display text-xl gradient-gold-text", children: "WADI GROUPS" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "A premier UAE business group operating across Healthcare, Trading, Import Export and Contracting industries." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-3 mt-6", children: [Globe, Camera, Briefcase].map((Icon, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "#", className: "glass h-9 w-9 grid place-items-center rounded-full hover:glow-gold transition", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { size: 16, className: "text-gold" }) }, i)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-gold text-sm uppercase tracking-widest mb-4", children: "Our Companies" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-2 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/companies/medical", className: "hover:text-gold", children: "Wadi Alhaya Medical Equipment LLC" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/companies/trading", className: "hover:text-gold", children: "Wadi Middle East Trading LLC" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/companies/import-export", className: "hover:text-gold", children: "Wadi Middle East Import Export LLC" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/companies/contracting", className: "hover:text-gold", children: "Wadi Al Naam Contracting LLC" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-gold text-sm uppercase tracking-widest mb-4", children: "Quick Links" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-2 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "hover:text-gold", children: "Home" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/about", className: "hover:text-gold", children: "About" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/companies", className: "hover:text-gold", children: "Companies" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/careers", className: "hover:text-gold", children: "Careers" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/contact", className: "hover:text-gold", children: "Contact" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-gold text-sm uppercase tracking-widest mb-4", children: "Contact" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "space-y-3 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { size: 16, className: "text-gold mt-0.5 shrink-0" }),
            " Al Quoz Third Block - B Office 311, Dubai, UAE"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { size: 16, className: "text-gold mt-0.5" }),
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "tel:+971554891800", className: "hover:text-gold", children: "+971 55 489 1800" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { size: 16, className: "text-gold mt-0.5" }),
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "mailto:info@wadialnaam.com", className: "hover:text-gold", children: "info@wadialnaam.com" })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-t border-[color:var(--gold)]/15 py-6 text-center text-xs text-muted-foreground", children: [
      "© ",
      (/* @__PURE__ */ new Date()).getFullYear(),
      " WADI GROUPS. All rights reserved."
    ] })
  ] });
}
function WhatsAppFab() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "a",
    {
      href: "https://wa.me/971554891800",
      target: "_blank",
      rel: "noreferrer",
      "aria-label": "Chat on WhatsApp",
      className: "fixed bottom-6 right-6 z-50 group",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute inset-0 rounded-full bg-[oklch(0.75_0.18_150)] blur-xl opacity-60 animate-glow-pulse" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative grid place-items-center h-14 w-14 rounded-full bg-[oklch(0.62_0.18_150)] text-white shadow-lg ring-2 ring-[color:var(--gold)]/40 group-hover:scale-110 transition-transform animate-float", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MessageCircle, { size: 24 }) })
      ]
    }
  );
}
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-7xl gradient-gold-text", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 text-xl", children: "Page not found" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "mt-6 inline-flex btn-gold rounded-full px-6 py-2 text-sm", children: "Go home" })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  const router2 = useRouter();
  reactExports.useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-2xl", children: "Something went wrong" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => {
      router2.invalidate();
      reset();
    }, className: "mt-6 btn-gold rounded-full px-6 py-2 text-sm", children: "Try again" })
  ] }) });
}
const Route$6 = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "WADI GROUPS — Luxury UAE Business Group" },
      { name: "description", content: "WADI GROUPS — a premier UAE business group across Healthcare, Trading, Import Export and Contracting industries." },
      { property: "og:title", content: "WADI GROUPS — Luxury UAE Business Group" },
      { property: "og:description", content: "WADI GROUPS — a premier UAE business group across Healthcare, Trading, Import Export and Contracting industries." },
      { property: "og:type", content: "website" },
      { name: "twitter:title", content: "WADI GROUPS — Luxury UAE Business Group" },
      { name: "twitter:description", content: "WADI GROUPS — a premier UAE business group across Healthcare, Trading, Import Export and Contracting industries." },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/4379ef52-16a4-45f6-92eb-65e2d57d4a75/id-preview-ffc06c53--5b68aac4-a01b-4d07-9a79-7409c411d3d4.lovable.app-1780239492649.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/4379ef52-16a4-45f6-92eb-65e2d57d4a75/id-preview-ffc06c53--5b68aac4-a01b-4d07-9a79-7409c411d3d4.lovable.app-1780239492649.png" },
      { name: "twitter:card", content: "summary_large_image" }
    ],
    links: [{ rel: "stylesheet", href: appCss }]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$6.useRouteContext();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(QueryClientProvider, { client: queryClient, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Header, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "pt-20", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Footer, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(WhatsAppFab, {})
  ] });
}
const $$splitComponentImporter$5 = () => import("./contact-CHSNm76B.mjs");
const Route$5 = createFileRoute("/contact")({
  head: () => ({
    meta: [{
      title: "Contact — WADI GROUPS"
    }, {
      name: "description",
      content: "Get in touch with WADI GROUPS. Reach our Dubai headquarters by phone, WhatsApp or email."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./careers-FcZZIiWp.mjs");
const Route$4 = createFileRoute("/careers")({
  head: () => ({
    meta: [{
      title: "Careers — WADI GROUPS"
    }, {
      name: "description",
      content: "Join WADI GROUPS. Submit your CV to be considered for future opportunities across our group of companies."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./about-C2tZu8GX.mjs");
const Route$3 = createFileRoute("/about")({
  head: () => ({
    meta: [{
      title: "About — WADI GROUPS"
    }, {
      name: "description",
      content: "Discover the vision, mission and journey of WADI GROUPS — a premier UAE multi-industry business group."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./index-RAXV3XvN.mjs");
const Route$2 = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "WADI GROUPS — Luxury UAE Business Group"
    }, {
      name: "description",
      content: "Building excellence across Healthcare, Trading, Import Export and Contracting industries in the UAE."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./companies.index-DSUbmHE3.mjs");
const Route$1 = createFileRoute("/companies/")({
  head: () => ({
    meta: [{
      title: "Our Companies — WADI GROUPS"
    }, {
      name: "description",
      content: "Explore the four companies of WADI GROUPS — across Healthcare, Trading, Import Export and Contracting."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
const medical = "/assets/medical-DGNByP2G.jpg";
const trading = "/assets/trading-Co2C7mdJ.jpg";
const importExport = "/assets/import-export-FvQ7s-9f.jpg";
const contracting = "/assets/contracting-DJaM-b8-.jpg";
const companies = [
  {
    slug: "medical",
    name: "Wadi Alhaya Medical Equipment LLC",
    industry: "Healthcare & Medical Equipment",
    description: "Advanced medical equipment, diagnostic technology, and healthcare solutions serving hospitals and clinics across the UAE.",
    image: medical
  },
  {
    slug: "trading",
    name: "Wadi Middle East Trading LLC",
    industry: "Trading & Commercial Solutions",
    description: "Strategic trading operations and commercial partnerships connecting global suppliers with the Middle East market.",
    image: trading
  },
  {
    slug: "import-export",
    name: "Wadi Middle East Import Export LLC",
    industry: "Import & Export",
    description: "International logistics, freight operations and worldwide trade routes built on reliability and scale.",
    image: importExport
  },
  {
    slug: "contracting",
    name: "Wadi Al Naam Contracting LLC",
    industry: "Construction & Contracting",
    description: "Construction, engineering and infrastructure development delivering landmark projects across the Emirates.",
    image: contracting
  }
];
const companyContent = {
  medical: {
    tagline: "Advancing Healthcare Through Innovation",
    overview: "Wadi Alhaya Medical Equipment LLC delivers cutting-edge medical technology and healthcare solutions to hospitals, clinics and diagnostic centers across the United Arab Emirates and the wider region.",
    vision: "To be the most trusted medical equipment partner in the Middle East, elevating patient care through innovation and uncompromising quality.",
    mission: "We empower healthcare providers with reliable, world-class equipment and services that improve outcomes, efficiency and accessibility.",
    services: [
      { title: "Diagnostic Equipment", description: "Imaging systems, laboratory analyzers and advanced diagnostic technology." },
      { title: "Hospital Solutions", description: "Surgical, ICU and patient-care equipment for modern healthcare facilities." },
      { title: "Medical Consumables", description: "High-quality consumables and disposables from certified manufacturers." },
      { title: "Service & Maintenance", description: "Installation, training and lifecycle support from a certified team." }
    ]
  },
  trading: {
    tagline: "Bridging Markets, Building Partnerships",
    overview: "Wadi Middle East Trading LLC operates a diversified trading portfolio, connecting global suppliers with businesses across the GCC through strategic commercial relationships.",
    vision: "To be the Middle East's most agile and trusted commercial trading partner, recognised for integrity and execution.",
    mission: "Deliver intelligent trading solutions that unlock value for clients, partners and the markets we serve.",
    services: [
      { title: "Wholesale Distribution", description: "Bulk distribution across consumer, industrial and commercial categories." },
      { title: "Sourcing & Procurement", description: "End-to-end sourcing from vetted international manufacturers." },
      { title: "Brand Representation", description: "Authorised representation for leading international brands in the UAE." },
      { title: "Market Intelligence", description: "Insight-led commercial strategy tailored to regional opportunities." }
    ]
  },
  "import-export": {
    tagline: "Moving the World, Powering Trade",
    overview: "Wadi Middle East Import Export LLC handles international freight, logistics and global trade flows with the precision and scale required by modern enterprise.",
    vision: "To be the logistics backbone of UAE international commerce, trusted for speed, transparency and resilience.",
    mission: "Engineer seamless global trade through integrated logistics, compliance and strategic partnerships.",
    services: [
      { title: "Sea Freight", description: "Full-container and LCL shipping across major global routes." },
      { title: "Air & Land Freight", description: "Expedited air cargo and regional overland transport." },
      { title: "Customs & Compliance", description: "Documentation, clearance and regulatory compliance services." },
      { title: "Warehousing & Distribution", description: "Bonded warehousing and last-mile distribution across the GCC." }
    ]
  },
  contracting: {
    tagline: "Engineering Tomorrow's Skylines",
    overview: "Wadi Al Naam Contracting LLC delivers construction, engineering and infrastructure projects of every scale — from luxury developments to commercial complexes.",
    vision: "To shape the future of the UAE's built environment with landmark projects defined by quality, safety and craftsmanship.",
    mission: "Build with precision, integrity and innovation — delivering value that lasts generations.",
    services: [
      { title: "Building Construction", description: "Residential, commercial and mixed-use developments delivered turnkey." },
      { title: "Civil & Infrastructure", description: "Roads, utilities and infrastructure for public and private clients." },
      { title: "Fit-Out & Interiors", description: "Premium interior fit-out for offices, retail and hospitality." },
      { title: "Engineering Consultancy", description: "Design, project management and engineering advisory services." }
    ]
  }
};
const $$splitNotFoundComponentImporter = () => import("./companies._slug-DRo7iZUe.mjs");
const $$splitComponentImporter = () => import("./companies._slug-C_TA0x19.mjs");
const Route = createFileRoute("/companies/$slug")({
  head: ({
    params
  }) => {
    const c = companies.find((x) => x.slug === params.slug);
    return {
      meta: [{
        title: c ? `${c.name} — WADI GROUPS` : "Company — WADI GROUPS"
      }, {
        name: "description",
        content: c?.description ?? "WADI GROUPS subsidiary."
      }, {
        property: "og:image",
        content: c?.image
      }]
    };
  },
  component: lazyRouteComponent($$splitComponentImporter, "component"),
  notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
const ContactRoute = Route$5.update({
  id: "/contact",
  path: "/contact",
  getParentRoute: () => Route$6
});
const CareersRoute = Route$4.update({
  id: "/careers",
  path: "/careers",
  getParentRoute: () => Route$6
});
const AboutRoute = Route$3.update({
  id: "/about",
  path: "/about",
  getParentRoute: () => Route$6
});
const IndexRoute = Route$2.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$6
});
const CompaniesIndexRoute = Route$1.update({
  id: "/companies/",
  path: "/companies/",
  getParentRoute: () => Route$6
});
const CompaniesSlugRoute = Route.update({
  id: "/companies/$slug",
  path: "/companies/$slug",
  getParentRoute: () => Route$6
});
const rootRouteChildren = {
  IndexRoute,
  AboutRoute,
  CareersRoute,
  ContactRoute,
  CompaniesSlugRoute,
  CompaniesIndexRoute
};
const routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  Route as R,
  companyContent as a,
  companies as c,
  logo as l,
  router as r
};
