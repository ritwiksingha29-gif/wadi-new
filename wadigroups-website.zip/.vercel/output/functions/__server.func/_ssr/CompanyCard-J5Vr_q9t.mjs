import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import { j as ArrowUpRight } from "../_libs/lucide-react.mjs";
function CompanyCard({ c, index }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      initial: { opacity: 0, y: 30 },
      whileInView: { opacity: 1, y: 0 },
      viewport: { once: true },
      transition: { duration: 0.6, delay: index * 0.1 },
      className: "group relative overflow-hidden rounded-2xl glass ring-gold-border",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-56 overflow-hidden", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: c.image, alt: c.name, className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-110", loading: "lazy" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-4 left-4 glass-strong rounded-full px-3 py-1 text-[10px] uppercase tracking-widest text-gold", children: c.industry })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-2xl mb-2 group-hover:text-gold transition", children: c.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground mb-5", children: c.description }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Link,
            {
              to: "/companies/$slug",
              params: { slug: c.slug },
              className: "inline-flex items-center gap-2 text-sm text-gold group/btn",
              children: [
                "Learn More",
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowUpRight, { size: 16, className: "transition-transform group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5" })
              ]
            }
          )
        ] })
      ]
    }
  );
}
export {
  CompanyCard as C
};
