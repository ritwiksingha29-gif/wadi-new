import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { S as SectionHeading } from "./SectionHeading-Cpey6AmV.mjs";
import { G as GoldParticles } from "./GoldParticles-CCOquF9w.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function About() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative py-24 overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(GoldParticles, { count: 18 }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-6 text-center max-w-3xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-[0.35em] text-gold mb-4", children: "About the Group" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-5xl md:text-6xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "WADI GROUPS" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-lg text-muted-foreground", children: "A diversified UAE business group built on vision, trust and uncompromising standards across four core industries." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "container mx-auto px-6 py-16", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid lg:grid-cols-3 gap-6", children: [{
      title: "Our Vision",
      text: "To be recognised as the UAE's most trusted multi-industry business group, leading with integrity, innovation and excellence across every sector we serve."
    }, {
      title: "Our Mission",
      text: "Deliver world-class products, services and solutions that empower clients, strengthen partnerships and shape the future of the regional economy."
    }, {
      title: "Our Values",
      text: "Integrity above all. Quality without compromise. Partnership over transaction. Vision beyond the horizon."
    }].map((b, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 20
    }, whileInView: {
      opacity: 1,
      y: 0
    }, viewport: {
      once: true
    }, transition: {
      delay: i * 0.1
    }, className: "glass rounded-2xl p-8 ring-gold-border", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-display text-2xl mb-3 gradient-gold-text", children: b.title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: b.text })
    ] }, b.title)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "container mx-auto px-6 py-24", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Journey", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Growth, Diversification & ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Future" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-3xl mx-auto space-y-6 text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "From its founding in Dubai, WADI GROUPS has grown into a multi-sector enterprise spanning Healthcare, Trading, Import Export and Contracting. Each company within the group operates with sectoral expertise, while drawing on the shared resources, governance and standards of a unified holding structure." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Our growth has been deliberate. Every new venture, every expansion has been driven by a strategic vision — to participate in the industries that build modern economies and improve modern lives. Healthcare equipment that saves lives. Trade that connects markets. Logistics that powers global commerce. Construction that shapes the cities of tomorrow." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "As we look ahead, we continue to invest in talent, technology and partnerships that will define the next chapter of our story — not only across the UAE, but throughout the Middle East and the world." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "container mx-auto px-6 pb-24", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Leadership", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Message from the ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Chairman" })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        y: 20
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true
      }, className: "relative max-w-3xl mx-auto glass-strong rounded-3xl p-8 md:p-12 ring-gold-border text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-6xl gradient-gold-text leading-none mb-4", children: "“" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg md:text-xl text-foreground/90 italic leading-relaxed", children: "Our journey has always been guided by a single principle — to build with purpose. At WADI GROUPS, we don't simply grow companies; we craft institutions that stand for trust, quality and the prosperity of every community we serve." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 inline-flex flex-col items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px w-16 gradient-gold-bg mb-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-2xl gradient-gold-text", children: "Dr. Irfan Ahmed" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-[0.3em] text-muted-foreground mt-1", children: "Chairman & Founder" })
        ] })
      ] })
    ] })
  ] });
}
export {
  About as component
};
