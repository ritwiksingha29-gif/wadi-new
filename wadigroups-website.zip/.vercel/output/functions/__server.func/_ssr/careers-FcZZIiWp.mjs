import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { S as SectionHeading } from "./SectionHeading-Cpey6AmV.mjs";
import { G as GoldParticles } from "./GoldParticles-CCOquF9w.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import { d as Check, U as Upload } from "../_libs/lucide-react.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function Careers() {
  const [submitted, setSubmitted] = reactExports.useState(false);
  const [fileName, setFileName] = reactExports.useState("");
  const onSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative py-24 overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(GoldParticles, { count: 20 }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "container mx-auto px-6 text-center max-w-3xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs uppercase tracking-[0.35em] text-gold mb-4", children: "Careers" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "font-display text-5xl md:text-6xl", children: [
          "Join ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "WADI GROUPS" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-6 text-lg text-muted-foreground", children: "We are always looking for talented professionals to become part of our growing organization across Healthcare, Trading, Import Export, and Contracting sectors." })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "container mx-auto px-6 pb-24", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-3xl mx-auto", children: submitted ? /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      scale: 0.95
    }, animate: {
      opacity: 1,
      scale: 1
    }, className: "glass-strong rounded-3xl p-12 text-center ring-gold-border", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-16 w-16 mx-auto rounded-full gradient-gold-bg grid place-items-center text-primary-foreground mb-6 glow-gold", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { size: 28 }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-3xl mb-3 gradient-gold-text", children: "Application Received" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "Thank you for your interest in WADI GROUPS. Your application has been successfully submitted. Our recruitment team will review your profile and contact you if a suitable opportunity becomes available." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit, className: "glass-strong rounded-3xl p-8 md:p-10 ring-gold-border space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Apply", title: /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        "Career ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "gradient-gold-text", children: "Application" })
      ] }), subtitle: "Submit your details below — we will reach out when an aligned opportunity arises." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid md:grid-cols-2 gap-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Full Name", name: "fullName", required: true }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Phone Number", name: "phone", type: "tel", required: true }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Email Address", name: "email", type: "email", required: true }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Nationality", name: "nationality", required: true }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Current Location", name: "location", required: true }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Position Applying For", name: "position", required: true }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Years of Experience", name: "experience", type: "number", required: true }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Education Qualification", name: "education", required: true })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs uppercase tracking-widest text-gold mb-2 block", children: "Upload CV / Resume" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "glass rounded-xl px-4 py-4 flex items-center gap-3 cursor-pointer hover:bg-white/5 transition", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { size: 18, className: "text-gold" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-muted-foreground", children: fileName || "Choose file (PDF, DOC, DOCX)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "file", name: "cv", accept: ".pdf,.doc,.docx", required: true, className: "hidden", onChange: (e) => setFileName(e.target.files?.[0]?.name ?? "") })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs uppercase tracking-widest text-gold mb-2 block", children: "Cover Message" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("textarea", { name: "message", rows: 5, required: true, maxLength: 1500, className: "w-full glass rounded-xl px-4 py-3 text-sm bg-transparent outline-none focus:ring-2 focus:ring-[color:var(--gold)]/40 placeholder:text-muted-foreground", placeholder: "Tell us about yourself and why you'd like to join WADI GROUPS..." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "submit", className: "btn-gold rounded-full px-8 py-3 text-sm font-medium w-full md:w-auto", children: "Submit Application" })
    ] }) }) })
  ] });
}
function Field({
  label,
  name,
  type = "text",
  required
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs uppercase tracking-widest text-gold mb-2 block", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("input", { name, type, required, maxLength: 200, className: "w-full glass rounded-xl px-4 py-3 text-sm bg-transparent outline-none focus:ring-2 focus:ring-[color:var(--gold)]/40 placeholder:text-muted-foreground" })
  ] });
}
export {
  Careers as component
};
