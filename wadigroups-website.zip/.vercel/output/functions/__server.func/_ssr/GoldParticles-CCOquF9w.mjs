import { j as jsxRuntimeExports } from "../_libs/react.mjs";
function GoldParticles({ count = 24 }) {
  const particles = Array.from({ length: count });
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute inset-0 overflow-hidden", children: particles.map((_, i) => {
    const size = 2 + Math.random() * 4;
    const left = Math.random() * 100;
    const delay = Math.random() * 12;
    const duration = 10 + Math.random() * 14;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "span",
      {
        className: "animate-particle absolute rounded-full",
        style: {
          left: `${left}%`,
          bottom: `-${size}px`,
          width: size,
          height: size,
          background: "var(--gold)",
          boxShadow: "0 0 8px var(--gold)",
          animationDelay: `${delay}s`,
          animationDuration: `${duration}s`,
          opacity: 0.6
        }
      },
      i
    );
  }) });
}
export {
  GoldParticles as G
};
